import collections, hashlib, json, pathlib, sys
root=pathlib.Path(sys.argv[1]);repo=pathlib.Path(sys.argv[2])
h=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((root/'report.json').read_text());s=json.loads((root/'summary.json').read_text());review=json.loads((root/'review.json').read_text())
assert r['status']=='completed' and r['mode']=='model' and r['modelCalls']==47 and r['modelCallsThisRun']==46
assert len(r['runs'])==36 and len({x['runId'] for x in r['runs']})==36
assert r['readiness']['passed'] and len(r['readiness']['tasks'])==6
assert all(x['passed'] for x in r['controls'].values())
assert len(r['controls']['negative']['results'])==13
assert r['controls']['invalidOutput']['calls']==2 and r['controls']['invalidOutput']['modelCalls']==0
assert abs(r['accounting']['reportedApiEquivalent']-1.0796458)<1e-9 and r['billedSpend'] is None
for filename, sha in r['source']['hashes'].items():assert h((repo/filename).read_bytes())==sha,filename
scopes=set();attempts=0;receipts=collections.Counter();protected_documents=0
for run in r['runs']:
 d=root/run['runId'];initial=(d/'initial.html').read_bytes();audit=json.loads((d/'initial-audit.json').read_text());scopes.add(audit['canvasId'])
 assert h(initial)==audit['input']['sha256'] and run['initialReady']
 assert 1 <= run['rounds'] <= 2
 assert run['human']=={'intent':None,'preference':None}
 assert initial==(repo/'test/fixtures/design-lint-eval'/run['taskId']/'initial.html').read_bytes()
 assert (d/'DESIGN.md').read_bytes()==(repo/'test/fixtures/design-lint-eval'/run['taskId']/'DESIGN.md').read_bytes()
 protected_documents+=len(run['protectedBefore'])
 prior=initial
 for attempt in run['attempts']:
  attempts+=1;ad=d/f"attempt-{attempt['round']}";stored=(ad/'stored.html').read_bytes();before=(ad/'before.html').read_bytes();a=json.loads((ad/'audit.json').read_text());receipt=json.loads((ad/'receipt.json').read_text())
  assert before==prior and h(before)==attempt['inputSha256'];prior=stored
  assert h(stored)==attempt['storedSha256']==a['input']['sha256']==attempt['browserEvidence']['inputHash']
  assert h((ad/'prompt.txt').read_bytes())==attempt['promptSha256']
  if attempt.get('accepted'):assert json.loads((ad/'candidate-output.txt').read_text())['html'].encode()==stored
  else:
   assert attempt['invalidOutput'] and stored==before
   try: json.loads((ad/'candidate-output.txt').read_text());raise AssertionError('Expected invalid JSON')
   except __import__('json').JSONDecodeError: pass
  assert h((ad/'candidate-output.txt').read_bytes())==attempt['candidateSha256']
  assert receipt==attempt['receipt'] and receipt['status'] in ['saved','unchanged','not-submitted']
  assert attempt['protectedUnchanged'] and not attempt['acceptedPolicyChange']
  assert json.loads((ad/'protected-after.json').read_text())==run['protectedBefore']
  receipts[receipt['status']]+=1
  if receipt['status']=='unchanged':assert stored==before and receipt['versionId']==attempt['capturedVersionId']
  elif receipt['status']=='saved':assert receipt['versionId']!=attempt['capturedVersionId']
  else:assert stored==before
  assert attempt['provider']['provider']=='claude-cli' and attempt['provider']['modelCalls']==1
  assert attempt['provider']['models']==['claude-sonnet-5'] and attempt['provider']['stopReason'] is None
  assert 0 < attempt['provider']['apiEquivalentCost'] <= attempt['allowance'] <= 0.138888888
  assert attempt['provider']['exitCode']==0
  assert attempt['browserEvidence']['available'] and len(attempt['browserEvidence']['viewports'])==2
 assert prior==(root/run['runId']/f"attempt-{run['rounds']}"/'stored.html').read_bytes()
 assert run['final']['score']['coverage']['complete']
 assert run['complete']==run['final']['score']['complete']
assert len(scopes)==36 and attempts==46
a=r['accounting']
assert a['carriedInvocations']==1 and a['calls']==47 and not a['pending'] and a['stopped'] is None and a['cap']==10
cost=sum(x['provider']['apiEquivalentCost'] for run in r['runs'] for x in run['attempts'])
assert abs(cost-a['reportedApiEquivalent'])<1e-9 and cost<=10
assert sum(x['complete'] for x in r['runs'])==28
assert s['verdict']=='inconclusive' and s['modelLift'] is None and not s['human']['available']
assert len(review['pairs'])==18
images=0
for pair in review['pairs']:
 assert pair['A']['intent'] is None and pair['B']['intent'] is None and pair['preference'] is None
 for key in ['reference','A','B']:
  for image in pair[key] if key=='reference' else pair[key]['images']:
   assert h((root/image['path']).read_bytes())==image['sha256'];images+=1
assert images==108
proof={'passed':True,'purpose':'Independent comparison of actual saved evidence files, initial frozen inputs, policy histories, receipts and screenshot hashes. Actual pilot outputs, invocation lineage and cost are independently verified; human judgments remain pending.','runs':36,'freshCanvasIds':len(scopes),'candidateAttempts':attempts,'receiptCounts':dict(receipts),'protectedDocumentSnapshots':protected_documents,'sourceHashesVerified':len(r['source']['hashes']),'reviewImageHashesVerified':images,'reviewPairs':18,'allActualHumanRatingsPending':True,'modelCalls':46,'totalCliInvocationsIncludingPriorRefusal':47,'estimatedApiEquivalentCost':cost,'verdict':s['verdict'],'reportSha256':h((root/'report.json').read_bytes())}
(root.parent/'isocan-phase5-conductor-model-output-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
